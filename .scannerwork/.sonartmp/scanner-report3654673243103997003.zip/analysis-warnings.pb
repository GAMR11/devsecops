�
�SCM provider autodetection failed. Please use "sonar.scm.provider" to define SCM of your project, or disable the SCM Sensor in the project settings.�����3�
xNode.js version 24 is not recommended, you might experience issues. Please use a recommended version of Node.js [16, 18]�����3